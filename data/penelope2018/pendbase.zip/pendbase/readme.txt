>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

The subdirectory './pdfiles/' contains the PENELOPE physics database. Do
not modify any of the files in this subdirectory. The executable binary
codes 'material.exe', 'tables.exe', and 'shower.exe' must be placed in
the directory '/pendbase/', where the present file is. These executables
assume that the original directory structure of the PENELOPE distribu-
tion package has been preserved. That is, they will work only if they
are in the parent directory of './pdfiles/'.

<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
