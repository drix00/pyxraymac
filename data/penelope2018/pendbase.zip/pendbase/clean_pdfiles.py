"""
Utility to clean pdfiles of previous PENELOPE releases.
"""

from pathlib import Path
import argparse


def cleanup(dirpath, dryrun=False):
    # Collect p?? files and their extension.
    filepaths = {}
    for filepath in dirpath.glob("*.p??"):
        filepaths.setdefault(filepath.stem, []).append(filepath.suffix)

    # Remove older files.
    for filename, exts in filepaths.items():
        if len(exts) == 1:
            continue

        # All extensions, except the last one.
        for ext in sorted(exts)[:-1]:
            filepath = dirpath.joinpath(filename).with_suffix(ext)
            if not dryrun:
                filepath.unlink()

            print(f"Removed {filepath}")


def main():
    parser = argparse.ArgumentParser(
        description="Clean pdfiles of previous PENELOPE releases"
    )

    parser.add_argument(
        "--dry", action="store_true", help="Dry run, do not remove any file"
    )
    parser.add_argument("pdfilesdir", type=Path, help="Path to pdfiles directory")

    args = parser.parse_args()

    cleanup(args.pdfilesdir, args.dry)


if __name__ == "__main__":
    main()
